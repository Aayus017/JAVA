import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class QuoteManager {

    private ArrayList<Quote> quotes;
    private ArrayList<String> authors;

    public QuoteManager() {
        quotes = new ArrayList<>();
        authors = new ArrayList<>();
        readQuotesFromFile();
        readAuthorsFromFile();
    }

    public void readAuthorsFromFile() {
        try (BufferedReader br = new BufferedReader(new FileReader("authors.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                authors.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void readQuotesFromFile() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

        try (BufferedReader br = new BufferedReader(new FileReader("quotes.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] quoteData = line.split(";");
                String author = quoteData[0];
                String text = quoteData[1];
                Date addDate = df.parse(quoteData[2]);
                String editor = quoteData[3];
                quotes.add(new Quote(author, text, editor, addDate));
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    public void listAllQuotes(User currentUser) {
        if (quotes.isEmpty()) {
            System.out.println("No quotes available.");
            return;
        }

        int pageNumber = 1;
        int quotesPerPage = 5;
        int totalPages = (int) Math.ceil((double) quotes.size() / quotesPerPage);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Page " + pageNumber + " of " + totalPages);
            int startIndex = (pageNumber - 1) * quotesPerPage;
            int endIndex = Math.min(startIndex + quotesPerPage, quotes.size());

            for (int i = startIndex; i < endIndex; i++) {
                System.out.println((i + 1) + ". " + quotes.get(i));
                System.out.println("-----------------------------------------------------");
            }

            System.out.println("What do you want to do?");
            System.out.println("M. Show more");
            System.out.println("B. Back to previous menu");

            if (currentUser != null && currentUser.isLogged()) {
                System.out.println("A. Add a quote");
                System.out.println("E. Edit a quote");
                System.out.println("D. Delete a quote");
            }

            String choice = scanner.nextLine().toUpperCase();

            switch (choice) {
                case "M":
                    if (pageNumber < totalPages) {
                        pageNumber++;
                    } else {
                        System.out.println("You have reached the end of the list.");
                    }
                    break;
                case "B":
                    break;
                case "A":
                    if (currentUser != null && currentUser.isLogged()) {
                        addQuote(currentUser);
                    } else {
                        System.out.println("You must be logged in to add a quote.");
                    }
                    break;
                case "E":
                    if (currentUser != null && currentUser.isLogged()) {
                        System.out.print("Enter the quote index to edit: ");
                        int editQuoteIndex = scanner.nextInt() - 1;
                        scanner.nextLine();
                        System.out.print("Enter the new author's name: ");
                        String newAuthor = scanner.nextLine().trim();
                        System.out.print("Enter the new quote text: ");
                        String newText = scanner.nextLine().trim();
                        editQuote(currentUser, editQuoteIndex, newAuthor, newText);
                    } else {
                        System.out.println("You must be logged in to edit a quote.");
                    }
                    break;
                case "D":
                    if (currentUser != null && currentUser.isLogged()) {
                        System.out.print("Enter the quote index to delete: ");
                        int deleteQuoteIndex = scanner.nextInt() - 1;
                        scanner.nextLine();
                        deleteQuote(currentUser, deleteQuoteIndex);
                    } else {
                        System.out.println("You must be logged in to delete a quote.");
                    }
                    break;
                default:
                    System.out.println("Invalid option.");
                    break;
            }

            if ("B".equals(choice)) {
                break;
            }
        }
    }

    public void addQuote(User user) {
        if (user.isLogged()) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the author's name: ");
            String author = scanner.nextLine().trim();
            System.out.print("Enter the quote text: ");
            String text = scanner.nextLine().trim();

            Quote newQuote = new Quote(author, text, user.getName(), new Date());
            newQuote.create();
            quotes.add(newQuote);
        } else {
            System.out.println("You must be logged in to add a quote.");
        }
    }


    public void getRandomQuote(User currentUser) {
        int randomIndex = (int) (Math.random() * quotes.size());
        Quote randomQuote = quotes.get(randomIndex);
        randomQuote.show();

        System.out.println("What do you want to do?");
        System.out.println("B. Back to previous menu");

        Scanner scanner = new Scanner(System.in);

        if (currentUser != null && currentUser.isLogged()) {
            System.out.println("A. Add a quote");
            System.out.println("E. Edit this quote");
            System.out.println("D. Delete this quote");
        }

        String choice = scanner.nextLine().toUpperCase();

        switch (choice) {
            case "B":
                break;
            case "A":
                if (currentUser != null && currentUser.isLogged()) {
                    addQuote(currentUser);
                } else {
                    System.out.println("You must be logged in to add a quote.");
                }
                break;
            case "E":
                if (currentUser != null && currentUser.isLogged()) {
                    System.out.print("Enter the new author's name: ");
                    String newAuthor = scanner.nextLine().trim();
                    System.out.print("Enter the new quote text: ");
                    String newText = scanner.nextLine().trim();
                    editQuote(currentUser, randomIndex, newAuthor, newText);
                } else {
                    System.out.println("You must be logged in to edit a quote.");
                }
                break;
            case "D":
                if (currentUser != null && currentUser.isLogged()) {
                    deleteQuote(currentUser, randomIndex);
                } else {
                    System.out.println("You must be logged in to delete a quote.");
                }
                break;
            default:
                System.out.println("Invalid option.");
                break;
        }
    }


    public void searchAuthor(String authorName) {
        for (Quote quote : quotes) {
            if (quote.getAuthor().equalsIgnoreCase(authorName)) {
                quote.show();
                System.out.println("-----------------------------------");
            }
        }
    }

    public void editQuote(User user, int quoteIndex, String newAuthor, String newText) {
        if (user.isLogged()) {
            Quote quoteToEdit = quotes.get(quoteIndex);
            if (user.getName().equals(quoteToEdit.getEditor()) || user.isAdmin()) {
                quoteToEdit.setAuthor(newAuthor);
                quoteToEdit.setText(newText);
                try {
                    FileWriter writer = new FileWriter("quotes.csv");
                    for (Quote quote : quotes) {
                        writer.write(quote.getAuthor() + ";" + quote.getText() + ";" + quote.getAddDate() + ";" + quote.getEditor() + "\n");
                    }
                    writer.close();
                } catch (IOException e) {
                    System.out.println("Error writing to quotes file");
                    e.printStackTrace();
                }
            } else {
                System.out.println("You can only edit quotes you added or if you are an admin.");
            }
        } else {
            System.out.println("You must be logged in to edit a quote.");
        }
    }
    public void deleteQuote(User user, int quoteIndex) {
        if (user.isLogged()) {
            Quote quoteToDelete = quotes.get(quoteIndex);
            if (user.getName().equals(quoteToDelete.getEditor()) || user.isAdmin()) {
                quotes.remove(quoteIndex);
                try {
                    File inputFile = new File("quotes.csv");
                    File tempFile = new File("temp_quotes.csv");
                    try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
                         BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            String[] quoteData = line.split(";");
                            if (!(quoteToDelete.getAuthor().equals(quoteData[0]) &&
                                    quoteToDelete.getText().equals(quoteData[1]) &&
                                    quoteToDelete.getEditor().equals(quoteData[3]))) {
                                bw.write(line + "\n");
                            }
                        }
                    }
                    inputFile.delete();
                    tempFile.renameTo(inputFile);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            } else {
                System.out.println("You can only delete quotes you added or if you are an admin.");
            }
        } else {
            System.out.println("You must be logged in to delete a quote.");
        }
    }

    public void deleteAllQuotesByEditor(String editor) {
        try {
            File inputFile = new File("quotes.csv");
            File tempFile = new File("temp_quotes.csv");
            try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
                 BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] quoteData = line.split(";");
                    if (!editor.equals(quoteData[3])) {
                        bw.write(line + "\n");
                    }
                }
            }
            inputFile.delete();
            tempFile.renameTo(inputFile);
            readQuotesFromFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void listUsers() {
        try (BufferedReader br = new BufferedReader(new FileReader("users.csv"))) {
            String line;
            System.out.println("User List:");
            while ((line = br.readLine()) != null) {
                String[] userData = line.split(";");
                System.out.println("Email: " + userData[0] + ", Name: " + userData[2]);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void deleteUser(User user, String userEmail) {
        if (user.isLogged()) {
            try {
                File inputFile = new File("users.csv");
                File tempFile = new File("temp_users.csv");
                try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
                     BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String[] userData = line.split(";");
                        if (!userEmail.equals(userData[0])) {
                            bw.write(line + "\n");
                        } else {
                            String deletedEditor = userData[2];
                            deleteAllQuotesByEditor(deletedEditor);
                        }
                    }
                }
                inputFile.delete();
                tempFile.renameTo(inputFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("You must be logged in to delete a user.");
        }
    }

    public void listAllAuthors() {
        if (authors.isEmpty()) {
            System.out.println("No authors available.");
            return;
        }

        System.out.println("Author List:");
        for (String author : authors) {
            System.out.println(author);
        }
    }

    public void addAuthor(String name) {
        if (!authors.contains(name)) {
            authors.add(name);

            try {
                FileWriter writer = new FileWriter("authors.csv", true);
                writer.write(name + "\n");
                writer.close();
            } catch (IOException e) {
                System.out.println("Error writing to authors file");
                e.printStackTrace();
            }
        }
    }

}