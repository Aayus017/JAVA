import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class User {
    private String email;
    private String password;
    private String name;
    private boolean logged;
    private boolean admin;

    public User(String email, String password, String name, boolean admin) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.logged = false;
        this.admin = admin;
    }

    public static void createAccount() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter your email address: ");
        String email = scanner.nextLine().trim();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine().trim();
        System.out.println("Are you an admin (y/n)");
        String isAdmin = scanner.nextLine().trim();
        if (isAdmin.equalsIgnoreCase("Y")) {
            
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.csv", true))) {
            writer.write(email + ";" + password + ";" + name);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    public void login() {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.csv"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(";");
                if (fields.length == 3 && fields[0].equals(email) && fields[1].equals(password)) {
                    this.email = email;
                    this.password = password;
                    this.name = fields[2];
                    this.logged = true;
                    return;
                }
            }
            System.out.println("Invalid email or password.");
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
    }

    public boolean isLogged() {
        return logged;
    }

    public void logout() {
        this.logged = false;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }
}
