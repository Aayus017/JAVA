import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Quote {
    private String author;
    private String text;
    private String editor;
    private Date addDate;

    public Quote(String author, String text, String editor, Date addDate) {
        this.author = author;
        this.text = text;
        this.editor = editor;
        this.addDate = addDate;
    }

    public void create() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("quotes.csv", true))) {
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = df.format(addDate);
            bw.write(author + ";" + text + ";" + formattedDate + ";" + editor + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void show() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = df.format(addDate);
        System.out.println("Author: " + author);
        System.out.println("Text: " + text);
        System.out.println("Added on: " + formattedDate);
        System.out.println("Added by: " + editor);
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getEditor() {
        return editor;
    }

    public void setEditor(String editor) {
        this.editor = editor;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    @Override
    public String toString() {
        return "\"" + this.text + "\"\n- " + this.author + "\nAdded by " + this.editor + " on " + this.addDate + "\n-----------------------------------------------------\n";
    }

}
