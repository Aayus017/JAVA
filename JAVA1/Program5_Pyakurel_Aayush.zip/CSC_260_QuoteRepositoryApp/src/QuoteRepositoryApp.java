import java.util.Scanner;

public class QuoteRepositoryApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        User currentUser = null;
        QuoteManager quoteManager = new QuoteManager();
        User adminUser = new User("admin@example.com", "admin_password", "Admin", true);


        while (true) {
            System.out.println("Welcome " + (currentUser == null ? "User" : currentUser.getName()) + ", what do you want to do?");
            System.out.println("1. List all the quotes");
            System.out.println("2. List all the authors");
            System.out.println("3. Add a quote");
            System.out.println("4. Add an author");
            System.out.println("5. Search for an author");
            System.out.println("6. Get a random quote");
            System.out.println("7. Create an account");
            System.out.println("8. Log in into your account");
            System.out.println("9. Log out of your account");
            System.out.println("10. Quit");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    quoteManager.listAllQuotes(currentUser);

                    if (currentUser != null && currentUser.isLogged()) {
                        System.out.println("Additional options:");
                        System.out.println("A. Add a quote");
                        System.out.println("E. Edit a quote");
                        System.out.println("D. Delete a quote");
                        System.out.println("Enter your choice or type 'B' to go back:");
                        String additionalChoice = scanner.nextLine().toUpperCase();

                        switch (additionalChoice) {
                            case "A":
                                quoteManager.addQuote(currentUser);
                                break;
                            case "E":
                                System.out.print("Enter the quote index to edit: ");
                                int editQuoteIndex = scanner.nextInt() - 1;
                                scanner.nextLine();
                                System.out.print("Enter the new author's name: ");
                                String newAuthor = scanner.nextLine().trim();
                                System.out.print("Enter the new quote text: ");
                                String newText = scanner.nextLine().trim();
                                quoteManager.editQuote(currentUser, editQuoteIndex, newAuthor, newText);
                                break;
                            case "D":
                                System.out.print("Enter the quote index to delete: ");
                                int deleteQuoteIndex = scanner.nextInt() - 1;
                                scanner.nextLine();
                                quoteManager.deleteQuote(currentUser, deleteQuoteIndex);
                                break;
                            case "B":
                                break;
                            default:
                                System.out.println("Invalid option.");
                                break;
                        }
                    }
                    break;
                case 2:
                    quoteManager.listAllAuthors();
                    break;
                case 3:
                    if (currentUser != null && currentUser.isLogged()) {
                        quoteManager.addQuote(currentUser);
                    } else {
                        System.out.println("You must be logged in to add a quote.");
                    }
                    break;
                case 4:
                    System.out.println("Enter the author's name:");
                    String newAuthorName = scanner.nextLine();
                    quoteManager.addAuthor(newAuthorName);
                    break;

                case 5:
                    System.out.println("Enter the author's name:");
                    String authorName = scanner.nextLine();
                    quoteManager.searchAuthor(authorName);
                    break;
                case 6:
                    quoteManager.getRandomQuote(currentUser);
                    break;
                case 7:
                    User.createAccount();
                    break;
                case 8:
                    System.out.println("Enter your name:");
                    String name = scanner.nextLine();
                    System.out.println("Enter your email:");
                    String email = scanner.nextLine();
                    System.out.println("Enter your password:");
                    String password = scanner.nextLine();
                    if (currentUser != null && currentUser.isLogged()) {
                        System.out.println("You are already logged in.");
                    } else {
                        User user = new User(email, password, name, false);
                        user.login();
                        if (user.isLogged()) {
                            System.out.println("Logged in as " + user.getName());
                            currentUser = user;
                        }
                    }
                    break;

                case 9:
                    if (currentUser != null && currentUser.isLogged()) {
                        currentUser.logout();
                        System.out.println("Logged out successfully.");
                    } else {
                        System.out.println("You are not logged in.");
                    }
                    break;
                case 10:
                    System.out.println("Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option.");
                    break;
            }
        }
    }
}
