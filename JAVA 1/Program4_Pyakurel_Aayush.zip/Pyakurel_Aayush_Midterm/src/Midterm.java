import java.util.Scanner;//scanner
import java.time.LocalDate;//Gives local date
import java.time.temporal.ChronoUnit;//calculate difference between dates

public class Midterm {
    public static double cityDistance(String city1, String city2) {//function to calculate distance between cities
        return (city1.length() + city2.length()) * 100;
        //the distance is calculated as : (letters in departure city+ letters in arrival city )* 100
    }

    public static double fuelPrice(int month, double cityDistance) {
        //fuel price calculator based on month and distance
        double gallonPrice;
        double gallonsUsed;
        double seatPrice;
        double totalSeats;
        if (month >= 1 && month <= 3) {
            gallonPrice = 4;
        } else if (month >= 4 && month <= 6) {
            gallonPrice = 8;
        } else if (month >= 7 && month <= 9) {
            gallonPrice = 15;
        } else {
            gallonPrice = 2;
        }
        if (cityDistance <= 500) {
            gallonsUsed = 10;
            totalSeats = 60;

        } else if (cityDistance > 500 && cityDistance <= 1000) {
            gallonsUsed = 12;
            totalSeats = 100;

        } else if (cityDistance > 1000 && cityDistance <= 2000) {
            gallonsUsed = 15;
            totalSeats = 150;
        } else if (cityDistance > 2000 && cityDistance <= 5000) {
            gallonsUsed = 22;
            totalSeats = 180;
        } else {
            gallonsUsed = 25;
            totalSeats = 200;

        }
        seatPrice = (gallonPrice * gallonsUsed * cityDistance) / totalSeats;
        return seatPrice;
    }

    public static double[] datebasedPrice(int[] dateArray, double Price) {
        //this method calculates price in context of date
        LocalDate presentDate = LocalDate.of(dateArray[0], dateArray[1], dateArray[2]);//gives local date
        LocalDate departureDate = LocalDate.of(dateArray[3], dateArray[4], dateArray[5]);
        long daysBetween = ChronoUnit.DAYS.between(presentDate, departureDate); //gives remaining days
        double factor=0;
        if (daysBetween >= 30) {
            factor = 0;
        } else if (daysBetween >= 20) {
            factor = 0.25;
        } else if (daysBetween >= 10) {
            factor =  0.50;
        } else if (daysBetween >= 0) {
            factor =  1.00;
        }
        else {
            System.out.println("Departure date has already passed");
            daysBetween = -1;//if the days between is less than 0 then that means departure date has already gone
        }
        Price += Price*factor;
        return new double[]{Price,daysBetween};//this method returns a double array of price and daysbetween
    }

    public static double[] luxuryPrice(double Price){
        double Comfort = Price + Price*0.25;
        double Business = Price + Price*0.75;
        double Luxury = Price*2;
        return new double[]{Price,Comfort,Business,Luxury};
        //calculates the final price based on class of airline luxury
    }


    public static void main(String[] args) {
        boolean Continue = true;//creating a Continue variable for the main loop
        while(Continue){
            Scanner scan = new Scanner(System.in);//Scanner
            System.out.println("Enter your departure city?");
            String departureCity = scan.nextLine().trim();//trim removes spaces between words
            System.out.println("Enter your arrival city?");
            String arrivalCity = scan.nextLine().trim();
            double distanceMiles = cityDistance(departureCity, arrivalCity);
            System.out.println("\nEnter the current date:\n");
            System.out.print("Year : ");
            int currentYear = scan.nextInt();
            System.out.print("Month : ");
            int currentMonth = scan.nextInt();
            System.out.print("Day : ");
            int currentDay = scan.nextInt();
            boolean repeat = true;//loop if the user wants to change the date
            while(repeat){
                System.out.println("\n\nEnter the departure date:\n");
                System.out.print("Year : ");
                int departureYear = scan.nextInt();

                System.out.print("Month : ");
                int departureMonth = scan.nextInt();

                System.out.print("Day : ");
                int departureDay = scan.nextInt();


                if((departureMonth<0 || departureMonth>12)||(departureDay>30 || departureDay<0)){
                    System.out.println("Date is invalid.");
                    System.exit(0);
                }
                if((currentMonth<0 || currentMonth>12)||(currentDay<0 || currentDay>30)){
                    System.out.println("Date is invalid.");
                    System.exit(0);
                }
                //passing departure month and distance miles to the fuelPrice method
                double Price = fuelPrice(departureMonth, distanceMiles);
                //creating an array of dates
                int[] dateArray = {currentYear, currentMonth, currentDay, departureYear, departureMonth, departureDay};
                double[] datePrice = datebasedPrice(dateArray, Price);
                if (datePrice[1] == -1) {//terminate the program if departure date has gone
                    System.exit(0);
                }
                Price = datePrice[0];
                System.out.println("There are four options for your ticket\nfrom " + departureCity + " to " + arrivalCity + "\n" +
                        "on " + departureMonth + "/" + departureDay + "/" + departureYear);
                double[] luxuryPrices = luxuryPrice(Price);
                System.out.printf("1: ECONOMY: $%.2f\n2: COMFORT: $%.2f\n3: BUSINESS: $%.2f" +
                        "\n4: Luxury: $%.2f", luxuryPrices[0], luxuryPrices[1], luxuryPrices[2], luxuryPrices[3]);
                System.out.println("\nSelect one of the previous options to purchase the ticket.\nOtherwise select\n" +
                        "C. Change Date." + "\nR. Back to the Beginning.");
                scan.nextLine();
                String userSelection = scan.nextLine();
                if (userSelection.equalsIgnoreCase("R")) {
                    repeat = false;
                }
                else if((!userSelection.equalsIgnoreCase("C"))&&(!userSelection.equalsIgnoreCase("R"))) {
                    System.out.println("-------------------------------------------------------------");
                    System.out.println("Flight Information :");
                    System.out.println("-------------------------------------------------------------");
                    switch (userSelection) {
                        //swtich case that runs on what luxury class the user selects

                        case "1" : System.out.printf("Class : ECONOMY Class \nDate : %d/%d/%d \nPrice : $%.2f", departureMonth, departureDay, departureYear, luxuryPrices[0]);
                            break;
                        case "2" : System.out.printf("Class : COMFORT Class \nDate : %d/%d/%d \nPrice : $%.2f", departureMonth, departureDay, departureYear, luxuryPrices[1]);
                            break;
                        case "3" : System.out.printf("Class : Business Class \nDate : %d/%d/%d \nPrice : $%.2f", departureMonth, departureDay, departureYear, luxuryPrices[2]);
                            break;
                        case "4" : System.out.printf("Class : Luxury Class \nDate : %d/%d/%d \nPrice : $%.2f", departureMonth, departureDay, departureYear, luxuryPrices[3]);
                            break;
                    }
                    System.out.println("\n-------------------------------------------------------------");
                    Continue = false;
                    break;
                }
            }
        }
    }
}
