import java.util.Scanner;
public class Java2 {
    public static void main(String[] args){
        // Initializing;
        String name, day, holiday, drink, mnv;
        int drinknum, dishnum, tipnum;
        double tip, total, price = 0;
        //Initializing the scanner;
        Scanner scan = new Scanner(System.in);
        // Taking user input for different values and data;
        System.out.println("Enter your Name: ");
        name = scan.nextLine();
        System.out.println("Hi "+name+",\nWelcome to FoodHub!");
        System.out.println("To get you started, what day is today?(Enter the full name of the day.)\nM. Monday\nT. Tuesday\nW. Wednesday\nR. Thursday\nF. Friday\nS. Saturday\nU. Sunday");
        day = scan.nextLine();
        holiday = "Sunday";
        //Testing if the selected day is a holiday;
        if(day.compareToIgnoreCase(holiday)==0){
            System.out.println("Sorry, "+name+" \nWe are closed on "+day);
        }else{
            System.out.println("Happy "+day+", "+name+"\nWhat would you like to drink:\n1. Water\t\t\t$0\n2. Soda\t\t\t\t$3\n3. Alcohol\t\t\t$18");
            drinknum = scan.nextInt();
            scan.nextLine();
            //Testing for the drink chosen;
            if(drinknum == 1){
                drink = "Water";
                price += 0;
            }else{
                if(drinknum == 2){
                    drink = "Soda";
                    price += 3;
                }else{
                    drink = "Alcohol";
                    price += 18;
                }
            }
            //Asking the user for the food preference;
            System.out.println("While you enjoy your "+drink+",\nwhat are your food preferences?\nM - You eat meat\nV - You are a vegetarian");
            mnv = scan.nextLine();
            //Testing if the user chose Meat;
            if(mnv.compareToIgnoreCase("M")==0){
                System.out.println("Perfect, "+name+"\nFor a meat eater like you,\non "+day+" we have the following:");
                //Testing the day selected by the user and showing the items available on that day;
                if(day.compareToIgnoreCase("monday")==0){
                    System.out.println("1. Chicken Dumplings\t\t\t$10\n2.Teriyaki Chicken\t\t\t$7");
                    dishnum = scan.nextInt();
                    scan.nextLine();
                    if(dishnum == 1){
                        price += 10;
                    }else{
                        price += 7;
                    }
                }else {
                    if (day.compareToIgnoreCase("tuesday") == 0) {
                        System.out.println("1. Fettuccine alfredo\t\t\t$12\n2. Hamburger\t\t\t$9");
                        dishnum = scan.nextInt();
                        scan.nextLine();
                        if (dishnum == 1) {
                            price += 12;
                        } else {
                            price += 9;
                        }
                    } else {
                        if (day.compareToIgnoreCase("wednesday") == 0) {
                            System.out.println("1. Curry Chicken\t\t\t$10\n2. Katti Roll\t\t\t$5");
                            dishnum = scan.nextInt();
                            scan.nextLine();
                            if (dishnum == 1) {
                                price += 10;
                            } else {
                                price += 5;
                            }
                        } else {
                            if (day.compareToIgnoreCase("thursday") == 0) {
                                System.out.println("1. Chicken Soup\t\t\t$9\n2. Tikka Chicken\t\t\t$7");
                                dishnum = scan.nextInt();
                                scan.nextLine();
                                if (dishnum == 1) {
                                    price += 9;
                                } else {
                                    price += 7;
                                }
                            } else {
                                if (day.compareToIgnoreCase("friday") == 0) {
                                    System.out.println("1. Lamb Curry\t\t\t$11\n2. Turkey Burger\t\t\t$6");
                                    dishnum = scan.nextInt();
                                    scan.nextLine();
                                    if (dishnum == 1) {
                                        price += 11;
                                    } else {
                                        price += 6;
                                    }
                                } else {
                                    System.out.println("1. Chicken Chilli\t\t\t$10\n2. Chicken Shapale\t\t\t$8");
                                    dishnum = scan.nextInt();
                                    scan.nextLine();
                                    if (dishnum == 1) {
                                        price += 10;
                                    } else {
                                        price += 8;
                                    }
                                }
                            }
                        }
                    }
                }
            }else {
                // This code will run if the user chose veg items;
                System.out.println("Perfect, " + name + "\nFor a vegetarian like you,\non " + day + " we have the following:");
                //Testing the day and displayong the items available on that day;
                if (day.compareToIgnoreCase("monday") == 0) {
                    System.out.println("1. Veg Dumplings\t\t\t$10\n2.Teriyaki Paneer\t\t\t$7");
                    dishnum = scan.nextInt();
                    scan.nextLine();
                    if (dishnum == 1) {
                        price += 10;
                    } else {
                        price += 7;
                    }
                } else {
                    if (day.compareToIgnoreCase("tuesday") == 0) {
                        System.out.println("1. Rice and Greens\t\t\t$12\n2. Grilled Cheese\t\t\t$9");
                        dishnum = scan.nextInt();
                        scan.nextLine();
                        if (dishnum == 1) {
                            price += 12;
                        } else {
                            price += 9;
                        }
                    } else {
                        if (day.compareToIgnoreCase("wednesday") == 0) {
                            System.out.println("1. Veggie Bowl\t\t\t$10\n2. Dal-Naan\t\t\t$5");
                            dishnum = scan.nextInt();
                            scan.nextLine();
                            if (dishnum == 1) {
                                price += 10;
                            } else {
                                price += 5;
                            }
                        } else {
                            if (day.compareToIgnoreCase("thursday") == 0) {
                                System.out.println("1. Mushroom Soup\t\t\t$9\n2. Paneer Tikka\t\t\t$7");
                                dishnum = scan.nextInt();
                                scan.nextLine();
                                if (dishnum == 1) {
                                    price += 9;
                                } else {
                                    price += 7;
                                }
                            } else {
                                if (day.compareToIgnoreCase("friday") == 0) {
                                    System.out.println("1. Eggplant stew\t\t\t$7\n2. Sandwich\t\t\t$6");
                                    dishnum = scan.nextInt();
                                    scan.nextLine();
                                    if (dishnum == 1) {
                                        price += 7;
                                    } else {
                                        price += 6;
                                    }
                                } else {
                                    System.out.println("1. Noodles\t\t\t$7\n2. Salad\t\t\t$3");
                                    dishnum = scan.nextInt();
                                    scan.nextLine();
                                    if (dishnum == 1) {
                                        price += 7;
                                    } else {

                                        price += 3;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // Displaying the total for user and asking if he would like to tip;
                System.out.println("Great, " + name + ", \nYour total is going to be $" + price + ".\nHow much would you like to tip?\n1. no tip\n2. 5%\n3. 10%\n4. 15%\n5. 20%");
                tipnum = scan.nextInt();
                //Testing the tip the user gave and calculating the total including tip;
                if (tipnum == 1) {
                    tip = 0;
                } else {
                    if (tipnum == 2) {
                        tip = (5 * price) / 100;
                    } else {
                        if (tipnum == 3) {
                            tip = (10 * price) / 100;
                        } else {
                            if (tipnum == 4) {
                                tip = (15 * price) / 100;
                            } else {
                                tip = (20 * price) / 100;
                            }
                        }
                    }
                }
                //This is the grand total;
                total = price + tip;
                //Displaying the grand total;
                System.out.println("Thank you so much, " + name + "\nyou will be billed $" + total + ". Thanks for visiting FoodHub!");
        }
    }
}
// AAAAaaaaand you’re done!