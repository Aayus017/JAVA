import java.util.Scanner;
public class java1a {
    public static void main(String args[]){
        //Initializing
        String name;
        int age;
        //Initializing doubles because some may enter the value of those in decimals.
        double salary, savings, intention, savingamt, wtime, rage;
        //Initializing scan as a scanner.
        //Taking every Input required: name, salary, age, savings(%), intention for final savings,
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter your name:");
        name = scan.nextLine();
        System.out.println("Enter your salary:");
        salary = scan.nextDouble();
        System.out.println("Enter your age:");
        age = scan.nextInt();
        System.out.println("Enter your monthly savings in percentage:");
        savings = scan.nextDouble();
        System.out.println("How much money do you want to have saved before retiring?");
        intention = scan.nextDouble();
        //Calculations:
        //Savings in amount = (salary*savings/100);
        savingamt = (salary*savings/100);
        //estimated working time(wtime) = (savings wanted at the time of retirement/savings per month)/12;
        //12 is used to convert the timefrom months to years;
        wtime = (intention/savingamt)/12;
        //Estimated time of retirement = current age + estimated working time(wtime);
        rage = wtime+age;
        System.out.println("---------------------------------------------------------");
        System.out.println("RETIREMENT PLAN FOR: "+ name);
        System.out.println("---------------------------------------------------------");
        System.out.println("You make $"+salary+"/month");
        System.out.println("You save "+savings+"% of your monthly salary ($"+savingamt+")");
        System.out.println("You plan to retire when you'll save $"+intention);
        System.out.println("You will have to work for "+wtime+" more years");
        System.out.println("You will be "+rage+" when you will retire");
        System.out.println("---------------------------------------------------------");

        System.out.println("GOOD LUCK by Aayush Pyakurel !");
    }
}

